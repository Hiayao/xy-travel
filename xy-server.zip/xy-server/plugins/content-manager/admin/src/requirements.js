const shouldRenderCompo = (plugin) => Promise.resolve(plugin);

export default shouldRenderCompo;
