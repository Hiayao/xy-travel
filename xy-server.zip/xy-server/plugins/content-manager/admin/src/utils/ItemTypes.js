export default {
  NORMAL: 'normalAttr',
  SORTABLEITEM: 'sortableItem',
  VARIABLE: 'variableAttr',
};