const bootstrap = (plugin) => Promise.resolve(plugin);

export default bootstrap;
