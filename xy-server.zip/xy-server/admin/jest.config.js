module.exports = {
  testPathIgnorePatterns: [
    '<rootDir>/',
  ]
};
