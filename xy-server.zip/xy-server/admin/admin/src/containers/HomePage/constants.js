export const GET_ARTICLES = 'app/HomePage/GET_ARTICLES';
export const GET_ARTICLES_SUCCEEDED = 'app/HomePage/GET_ARTICLES_SUCCEEDED';
export const ON_CHANGE = 'app/HomePage/ON_CHANGE';
export const SUBMIT = 'app/HomePage/SUBMIT';
export const SUBMIT_SUCCEEDED = 'app/HomePage/SUBMIT_SUCCEEDED';
